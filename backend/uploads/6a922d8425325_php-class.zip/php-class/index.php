<?php 
require_once "Connection.php";
require_once "Todo.php";


$todo = Todo::find(1);

// var_dump($todo);exit;
$todo->task = "lorem ipsum abc 1245";
$todo->save();


exit;